# The Personal Trainer Club API

# Node JS express site 
[![Deploy to Azure](http://azuredeploy.net/deploybutton.png)](https://azuredeploy.net/)

